# Skyline Bank and Whitford Global College: website demos

Three pages:
- `index.html`: home page linking to both clients
- `bank.html`: Skyline Bank of India (SBOIFDCertificate ERC-721 + SBOIRewardToken ERC-20)
- `college.html`: Whitford Global College (WhitfordCredential ERC-721 + WhitfordPoints ERC-20)

The pages need an internet connection, because they load the ethers.js library and talk to Sepolia through MetaMask.

## 1. Run the website

MetaMask does not work on pages opened by double-clicking (`file://`). Serve the folder instead, using either option:

- **VS Code:** install the "Live Server" extension, open this folder, right-click `index.html` and choose "Open with Live Server".
- **Python:** open a terminal in this folder and run `python -m http.server 8000`, then go to http://localhost:8000

## 2. Connect your contracts

1. Deploy the contracts in Remix on Sepolia first (see the test and demo guide).
2. Open the site and go to the **Setup** tab.
3. Your deployed addresses are already filled in. Only change them if you redeploy.
4. Optional: add the block number the contracts were deployed in (shown on Etherscan). This makes history load faster.
5. Click **Connect MetaMask**.

## 3. Demo flow: Skyline Bank (bank.html)

Use the **Bank** account (the one that deployed the contracts) for the console, and the **Customer** account for My account.

1. Bank console > Verify the customer's wallet.
2. Bank console > Mint Maturity Miles > "Welcome bonus (10)" > Mint.
3. Bank console > Issue an FD certificate (12 months, matures in 5 minutes).
4. Bank console > Set a perk (for example "Forex charge waiver", 200).
5. Switch MetaMask to Customer > My account shows the certificate and 10 miles.
6. After 5 minutes, back as Bank: Mature the certificate, then "Calculate reward" (Rs 100000, 12 months = 500) and Mint.
7. As Customer: redeem the perk. The balance drops and the activity log shows it.
8. Verify a certificate: anyone can check a certificate number.

## 4. Demo flow: Whitford Global College (college.html)

Use the **Registrar** account for the console and the **Student** account for My account.

1. Registrar console > Enrol the student's wallet.
2. Award Merit Points a few times (attendance, assignment, module passed).
3. Set a campus perk (for example "Canteen coffee", 30).
4. Issue a credential: choose any PDF as the certificate file. **Copy the salt shown.**
5. As Student: My account shows points, tier and the credential; redeem the coffee.
6. Employer check: enter the credential number, or upload the same PDF with the salt. Change the PDF and try again to show a fake being caught.
7. Registrar: revoke the credential and check again to show it is now invalid.

## Notes

- Both accounts need a little Sepolia ETH for gas.
- Errors from the contract (for example "Soulbound: transfers disabled" or "Amount exceeds cap") are shown in the message box at the bottom right. These are useful screenshots too.
- The contracts and pages have not been tested against a live deployment yet; send any error message for help.
